package com.mycompany.app.service;

import com.mycompany.app.model.Greeting;

public interface GreetingService {

	Greeting generateMessage(String name);

}
